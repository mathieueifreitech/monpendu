angular.module('demo.adMob.ctrl', [])

  .controller('AdMobCtrl', function ($scope, $log, $cordovaPreferences) {

  });
