angular.module('demo.socialSharing.ctrl', [])

  .controller('SocialSharingCtrl', function ($scope, $log, $cordovaPreferences) {

  });
